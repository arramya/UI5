(function(){

  "use strict";

  sap.ui.define(["so_overview/util/BaseController",
      'jquery.sap.global','sap/m/MessageToast',
      'sap/m/MessageBox',
      'sap/ui/core/routing/History',
      'sap/m/UploadCollectionParameter',],function(BaseController,jQuery,
   		   MessageToast,MessageBox,History,UploadCollectionParameter){


    return BaseController.extend("so_overview.views.postjob",{
    	onInit: function(){
			
			//this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
    		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
    	       oRouter.getRoute("postjob").attachMatched(this._onRouteMatched, this);  
    	       this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
    	        
    	   	this.getView().byId("p1").setCount(tablen);
    	   //	this.getView().byId("p1").setPosition(0);
			
		},
		
		
		
		
		
		lang: function(oEvent) {
		      var control = oEvent.getSource();
	        var state = control.getState();
	         if (state) {
	           var i18nModel = new sap.ui.model.resource.ResourceModel({bundleUrl:"i18n/i18n.properties", bundleLocale:"en"});
	            sap.ui.getCore().setModel(i18nModel, "i18n");
	        } else {
	           var i18nModel = new sap.ui.model.resource.ResourceModel({bundleUrl:"i18n/i18n_AR.properties", bundleLocale:"de"});
	            sap.ui.getCore().setModel(i18nModel, "i18n");
	        }
	    },
		
		
		
		
		
		
		onNavBack:function(){
				
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo('Master'); 
			},
			
			  _onRouteMatched:function(oEvent){
		    	  
		    		var oArgs, oView;
		    	/*var	con = oEvent.getParameter("ItemNumber");
		    	console.log(con);*/
		    		
					oArgs = oEvent.getParameter("arguments"); 
					SalesOrderNumber = oArgs["SalesOrderNumber"];
							con=oArgs["con"];
							
					 oView = this.getView();
				 	  
					oView.bindElement({
				 		 path : "/OrderItems(ItemNumber='"+con+"',SalesOrderNumber='"+SalesOrderNumber+"')",
						
						events : {
							dataRequested: function () {
								oView.setBusy(true);
							},
							dataReceived: function () {
								oView.setBusy(false);
							 
							}
						}
					});
					
					
					
					
					 
		    },
		    
		    
// PagingButton function	
		    
		    
		   /* change1:function(oEvent)
		    {
		    	 var pos1=oEvent.getParameter("newPosition") -1;	
					// alert(pos1);
					
					var sPath = "/OrderItems";
					 var oFilters = [new sap.ui.model.Filter("SalesOrderNumber", sap.ui.model.FilterOperator.EQ, SalesOrderNumber)];
			 		
					           var oController = this;
					          oModel.read(sPath,{
					        	  filters:oFilters,
					          
					              success: function(oData,oResponse){
					            	  console.log(oData);
					            	  oMol = oData.__count;
					            	  console.log(oMol)
		    	
		    	 if ((i >= 0) && (i < tablen)) {
     				
         			
            		 // alert(i);
            	  con = oData.results[i].ItemNumber;
            	  SalesOrderNumber = oData.results[0].SalesOrderNumber;	
                	Counthead.setText("Sales Orders ("+oMol+")")
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
	                oController.oRouter.navTo("postjob",{
	                	SalesOrderNumber : SalesOrderNumber ,
	                	con:con
                          });  
	                i++;
            	
            	  }
                     		            
					              },
					              error: function(oResponse){
						                 //alert("Error");
						            }
						          })
		    },*/
		
			onPositionChange: function (oEvent) {
				//alert(tablen);
				
				 var pos1=oEvent.getParameter("newPosition") -1;	
				// alert(pos1);
				
				var sPath = "/OrderItems";
				 var oFilters = [new sap.ui.model.Filter("SalesOrderNumber", sap.ui.model.FilterOperator.EQ, SalesOrderNumber)];
		 		
				           var oController = this;
				          oModel.read(sPath,{
				        	  filters:oFilters,
				          
				              success: function(oData,oResponse){
				            	  console.log(oData);
				            	  oMol = oData.__count;
				            	  console.log(oMol)
				            	  
				            	  if(pos1==0)
				            		  {
				            		  	pos1=pos1+1;
				            		  	 con = oData.results[0].ItemNumber;
				            		  	SalesOrderNumber = oData.results[0].SalesOrderNumber;	
				                    	Counthead.setText("Sales Orders ("+oMol+")")
										var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						                oController.oRouter.navTo("postjob",{
						                	SalesOrderNumber : SalesOrderNumber ,
						                	con:con
					                          }); 
				            		  
				            		  }
				            	  else
				            		  {
				            		 
				            		  if ((i = oBinding[1]) && (i < tablen)) {
				            				
				            			
				            		 // alert(i);
				            			  pos1=pos1+1;
				            	  con = oData.results[i].ItemNumber;
				            	  SalesOrderNumber = oData.results[0].SalesOrderNumber;	
			                    	Counthead.setText("Sales Orders ("+oMol+")")
									var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					                oController.oRouter.navTo("postjob",{
					                	SalesOrderNumber : SalesOrderNumber ,
					                	con:con
				                          });  
					                i++;
				            	
				            	  }
				            	
				                     		                    
				                    /*if(oMol=="0"){			                     
				                    	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						                oController.oRouter.navTo("");
					                    
					                }
				                    else
				                    {
				                    	SalesOrderNumber = oData.results[0].SalesOrderNumber;	
				                    	Counthead.setText("Sales Orders ("+oMol+")")
										var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						                oController.oRouter.navTo("postjob",{
						                	SalesOrderNumber : SalesOrderNumber ,
						                	con:con
					                          });                
									}*/
				            	
				            	  	}
				                  
		  		            },
				            error: function(oResponse){
				                 //alert("Error");
				            }
				          })
	 			
				
					
				
			},
    });
    
    
  });
})();