(function(){
	"use strict";
	sap.ui.define("so_overview.util.BaseController",["sap/ui/core/mvc/Controller"],function(Controller){
		
		return Controller.extend("so_overview.util.BaseController",{
			
			
			
			
		});
	
	});
	
})();