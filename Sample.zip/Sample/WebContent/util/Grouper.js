jQuery.sap.declare("VIM_App.util.Grouper");

VIM_App.util.Grouper = {

	GrossAmount: function(oContext){
		var sKey,sText;
		var sAmount = oContext.getProperty("GrossAmount");
		
		if (sAmount < 5000 ){
			sKey = "A1";
			sText = "Less than 5000";
		} else if ( sAmount > 5000 && sAmount <= 10000 ){
			sKey = "A2";
			sText = "Between 5K to 10K";
		} else {
			sKey = "A3";
			sText = "Greater than 10000";
		}
		
		return {
			key: sKey,
			text: sText
		};
	},
	
	LifecycleStatus: function(oContext){
		var sKey,sText;
		var sStatus = oContext.getProperty("LifecycleStatus");
		
		if (sStatus === "N"){
			sKey = "N";
			sText = "New";
		} else if (sStatus === "P"){
			sKey = "P";
			sText = "In Process";
		}
		return {
			key: sKey,
			text: sText
		};	
	}
		
}