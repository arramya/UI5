jQuery.sap.declare("VIM_App.util.Formatter");

VIM_App.util.Formatter = {
	statusText : function(sValue){
		if (sValue === 'N'){
			return "New";
		} else if (sValue === 'P'){
			return "In Process";
		}
	},
	
	statusState: function(sValue1,sValue2){
		
		if (sValue1 === 'N'){
			return "Success";
		} else if (sValue1 === 'P'){
			return "Warning";
		}
		return "Success";
	}
		
} 